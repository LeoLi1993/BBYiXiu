//window.onload = function () {
//    var i, j = 0;
//    var as = document.getElementsByTagName('a'), len = as.length;
//    for (;i<len;i++) {
//        as[i].onclick=function(){
//            for(var j=0;j<len;j++){
//                if(as[j].className=='active'){
//                    as[j].className = '';
//                    break;
//                }
//            }
//            return this.className = 'active';
//        }
//    }
//} 
